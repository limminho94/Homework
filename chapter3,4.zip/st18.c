#include <stdio.h>

int main()
{
    int i;
    for(i = 5; i <= 15; i++)
    {
        printf("%d ", i);
    }
    printf("\n");
}